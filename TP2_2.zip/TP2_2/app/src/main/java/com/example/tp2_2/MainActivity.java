package com.example.tp2_2;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;


public class MainActivity extends Activity implements SensorEventListener {

    private SensorManager mSensorManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main);

        TextView textInfo = (TextView)findViewById(R.id.info);

        Sensor gravSensor;
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        if ((gravSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY)) != null && (gravSensor.getVendor().contains("Google Inc.")) &&
                (gravSensor.getVersion() == 3)){
            textInfo.setText("Félicitations, vous avec les capteurs nécessaires !");
        }
        else{
            textInfo.setText("Malheureusement, vous n'avez pas les capteurs nécessaires pour bénéficier de toutes les fonctionnalités.");
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
