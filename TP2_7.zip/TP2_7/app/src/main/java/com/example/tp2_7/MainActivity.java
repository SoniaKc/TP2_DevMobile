package com.example.tp2_7;

import android.app.Activity;

public class MainActivity extends Activity {
}
