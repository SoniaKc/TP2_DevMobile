package com.example.tp2_6;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ImageView;


public class MainActivity extends Activity implements SensorEventListener {

    private SensorManager mSensorManager;
    private Sensor proximity;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main);

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        proximity = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);

        boolean accSupported = mSensorManager.registerListener(this, proximity, SensorManager.SENSOR_DELAY_UI);
        if (!accSupported) {
            mSensorManager.unregisterListener(this, proximity);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            ImageView img = findViewById(R.id.imgFar);
            float prox = event.values[0];
            if (prox <= 3){
                img.setImageResource(R.drawable.maskassclose);
            } else if (prox <= 7) {
                img.setImageResource(R.drawable.maskassmid);
            } else {
                img.setImageResource(R.drawable.maskassfar);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }
    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, proximity, SensorManager.SENSOR_DELAY_NORMAL);
    }
}
