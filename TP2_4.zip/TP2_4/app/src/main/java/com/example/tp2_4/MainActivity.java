package com.example.tp2_4;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager mSensorManager;
    private Sensor accelerometre;
    private TextView tvDirection;
    private static final float cteFiltre = 0.8f;
    private float[] gravity = new float[3];


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main);
        tvDirection = findViewById(R.id.tv);

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        accelerometre = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        boolean supported = mSensorManager.registerListener(this, accelerometre, SensorManager.SENSOR_DELAY_NORMAL);
        if (!supported) {
            mSensorManager.unregisterListener(this, accelerometre);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            // OK mais peut mieux faire
            /*
            TextView tvx = findViewById(R.id.x);
            TextView tvy = findViewById(R.id.y);

            float oldX = Float.parseFloat(tvx.getText().toString());
            float oldY = Float.parseFloat(tvy.getText().toString());

            float x = event.values[0];
            float y = event.values[1];

            if (Math.abs(x) > Math.abs(y)){
                if (x < oldX){
                    tvDirection.setText("Gauche");
                    tvx.setText(String.valueOf(x));
                }
                else if (x > oldX){
                    tvDirection.setText("Droite");
                    tvx.setText(String.valueOf(x));
                }
            }else if (Math.abs(x) < Math.abs(y)){
                if (y < oldY) {
                    tvDirection.setText("Bas");
                    tvy.setText(String.valueOf(y));
                }
                else if (y > oldY) {
                    tvDirection.setText("Haut");
                    tvy.setText(String.valueOf(y));
                }
            }
            */

            // Chiffres d'accélération
            float X = event.values[0];
            float Y = event.values[1];
            float Z = event.values[2];

            // Formule pour filter la gravité liée aux chiffres d'accélération
            gravity[0] = cteFiltre * gravity[0] + (1 - cteFiltre) * X;
            gravity[1] = cteFiltre * gravity[1] + (1 - cteFiltre) * Y;
            gravity[2] = cteFiltre * gravity[2] + (1 - cteFiltre) * Z;

            // Formule de l'accélération linéaire
            float linearAccelerationX = event.values[0] - gravity[0];
            float linearAccelerationY = event.values[1] - gravity[1];
            float linearAccelerationZ = event.values[2] - gravity[2];


            if (linearAccelerationX > 2) {
                tvDirection.setText("Gauche");
            } else if (linearAccelerationX < -2) {
                tvDirection.setText("Droite");
            }

            if (linearAccelerationY > 2){
                tvDirection.setText("Bas");
            }else if (linearAccelerationY < -2) {
                tvDirection.setText("Haut");
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }
    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, accelerometre, SensorManager.SENSOR_DELAY_NORMAL);
    }
}
