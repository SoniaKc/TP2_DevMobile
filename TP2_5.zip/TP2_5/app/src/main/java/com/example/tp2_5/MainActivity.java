package com.example.tp2_5;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager mSensorManager;
    private CameraManager cameraManager;
    private String cameraID;
    private boolean onOff = false;
    private TextView OnOff;
    private ImageView imageV;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main);

        imageV = findViewById(R.id.image);
        OnOff = findViewById(R.id.OnOff);


        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        Sensor accelerometre = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        boolean accSupported = mSensorManager.registerListener(this, accelerometre, SensorManager.SENSOR_DELAY_UI);
        if (!accSupported) {
            mSensorManager.unregisterListener(this, accelerometre);
        }

        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            cameraID = cameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = Math.abs(event.values[0]);
            float y = event.values[1];

            if (x > 6 && y > 11) {
                try {
                    cameraManager.setTorchMode(cameraID, !onOff);
                    onOff = !onOff;

                    if (onOff){
                        imageV.setImageResource(R.drawable.on);
                        OnOff.setText("Allumé");
                    } else {
                        imageV.setImageResource(R.drawable.off);
                        OnOff.setText("Éteint");
                    }
                } catch (CameraAccessException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onPause() {
        mSensorManager.unregisterListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER));
        super.onPause();
    }
    @Override
    protected void onResume() {
        mSensorManager.registerListener(this, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_UI);
        super.onResume();
    }
}
