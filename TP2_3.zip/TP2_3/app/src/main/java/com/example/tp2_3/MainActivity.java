package com.example.tp2_3;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener {
    private SensorManager mSensorManager;
    private Sensor accelerometre;
    private TextView tvAcc;
    private LinearLayout ll;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_main);
        tvAcc = findViewById(R.id.tv);
        ll = findViewById(R.id.LL);

        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometre = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        boolean supported = mSensorManager.registerListener(this, accelerometre, SensorManager.SENSOR_DELAY_UI);
        if (!supported) {
            mSensorManager.unregisterListener(this, accelerometre);
        }
    }


    @SuppressLint("SetTextI18n")
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {

            float x = Math.abs(event.values[0]);
            float y = event.values[1];

            double moy = (x+y)/2;

            // faible accélération
            if (moy < 6){
                // Vert
                ll.setBackgroundColor(0xff00ff00);
                tvAcc.setText(Double.toString(moy));
            }
            // accélération moyenne
            else if (moy < 8){
                // Noir
                ll.setBackgroundColor(0xff000000);
                tvAcc.setText(Double.toString(moy));
            }
            // forte accélération
            else {
                // Rouge
                ll.setBackgroundColor(0xffff0000);
                tvAcc.setText(Double.toString(moy));
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
    @Override
    protected void onPause() {
        super.onPause();
        mSensorManager.unregisterListener(this);
    }
    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(this, accelerometre, SensorManager.SENSOR_DELAY_UI);
    }

}
